<?php
// Server configuration
define('SERVER_IP', '192.168.0.17');
define('SERVER_PORT', 10980);
define('SOCKET_TIMEOUT', 30);

// Character encoding
define('CHARSET', 'UTF-8');

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Logging configuration
define('LOG_FILE', 'server_monitor.log');

// Security settings
define('MAX_CONNECTIONS', 100);
define('REQUEST_TIMEOUT', 30);

// Room types configuration
$ROOM_TYPES = array(
    'A' => 'Ranked - Circuit',
    'B' => 'Ranked - Sprint',
    'C' => 'Ranked - Drift',
    'D' => 'Ranked - Drag',
    'E' => 'Unranked - Circuit',
    'F' => 'Unranked - Sprint',
    'G' => 'Unranked - Drift',
    'H' => 'Unranked - Drag'
); 