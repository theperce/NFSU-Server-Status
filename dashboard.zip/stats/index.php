<?php
declare(strict_types=1);
require_once '../config.php';

class Room {
    private string $type;
    private string $name;
    private int $roomCount;
    private int $userCount;
    private array $users;

    public function __construct(string $type = '', string $name = '') {
        $this->type = $type;
        $this->name = $name;
        $this->roomCount = 0;
        $this->userCount = 0;
        $this->users = [];
    }

    public function addUser(string $username): void {
        $this->users[] = $username;
        $this->userCount++;
    }

    public function getType(): string {
        return $this->type;
    }

    public function getName(): string {
        return $this->name;
    }

    public function getRoomCount(): int {
        return $this->roomCount;
    }

    public function getUserCount(): int {
        return $this->userCount;
    }

    public function getUsers(): array {
        return $this->users;
    }

    public function setRoomCount(int $count): void {
        $this->roomCount = $count;
    }
}

class ServerStats {
    private array $rooms;
    private array $serverData;
    private ?string $error;

    public function __construct() {
        $this->rooms = [];
        $this->error = null;
        $this->initializeServerData();
    }

    private function initializeServerData(): void {
        $this->serverData = [
            'usercount' => 0,
            'roomcount' => 0,
            'timeonline' => 0,
            'platform' => '',
            'version' => '',
            'servername' => ''
        ];
    }

    public function connect(): bool {
        $fp = @fsockopen(SERVER_IP, SERVER_PORT, $errno, $errstr, SOCKET_TIMEOUT);
        
        if (!$fp) {
            $this->error = "Server connection failed: $errstr ($errno)";
            $this->logError($this->error);
            return false;
        }

        $serverData = fgets($fp);
        fclose($fp);

        if (strlen(trim($serverData)) > 0) {
            $this->parseServerData($serverData);
        }

        return true;
    }

    private function parseServerData(string $data): void {
        $parts = explode("~~~", $data);
        if (count($parts) >= 2) {
            $serverInfo = explode("|", $parts[0]);
            if (count($serverInfo) >= 6) {
                $this->serverData = [
                    'usercount' => (int)$serverInfo[0],
                    'roomcount' => (int)$serverInfo[1],
                    'timeonline' => (int)$serverInfo[2],
                    'platform' => $serverInfo[3],
                    'version' => $serverInfo[4],
                    'servername' => $serverInfo[5]
                ];
            }

            $this->parseRoomData($parts[1]);
        }
    }

    private function parseRoomData(string $data): void {
        $rooms = explode("]", $data);
        foreach ($rooms as $roomData) {
            $parts = explode("[", $roomData);
            if (count($parts) >= 2) {
                $roomInfo = explode("|", $parts[0]);
                if (count($roomInfo) >= 2) {
                    $roomName = str_replace("\"", "", $roomInfo[0]);
                    $roomType = substr($roomName, 0, 1);
                    $room = new Room($roomType, substr($roomName, 2));
                    $room->setRoomCount((int)$roomInfo[1]);

                    if (isset($parts[1]) && !empty($parts[1])) {
                        $users = explode("|", $parts[1]);
                        foreach ($users as $user) {
                            if (!empty($user)) {
                                $room->addUser($user);
                            }
                        }
                    }

                    $this->rooms[] = $room;
                }
            }
        }
    }

    private function logError(string $message): void {
        error_log(date('[Y-m-d H:i:s] ') . $message . "\n", 3, LOG_FILE);
    }

    public function getError(): ?string {
        return $this->error;
    }

    public function render(): void {
        header('Content-Type: text/html; charset=' . CHARSET);
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>NFS:U LAN Server "<?php echo htmlspecialchars($this->serverData['servername']); ?>" 
                   @ <?php echo SERVER_IP; ?> : 
                   <?php echo $this->error ? 'Offline' : 'Usercount ' . $this->serverData['usercount']; ?></title>
            <meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET; ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <script type="text/javascript">
                let previousData = {};

                // Массив спортивных автомобилей
                const cars = ['🏎️', '🚗', '🚙', '🚓', '🚦'];
                let currentCarIndex = 0;
                
                function getRandomCar() {
                    return cars[Math.floor(Math.random() * cars.length)];
                }

                // Функция для анимации элемента
                function driftAnimation(element, direction = 'left') {
                    element.style.animation = `drift-${direction} 0.5s ease-out`;
                    element.addEventListener('animationend', () => {
                        element.style.animation = '';
                    }, {once: true});
                }

                // Функция для сравнения и анимации изменений
                function animateChanges(newElement, oldElement) {
                    if (!oldElement) return;

                    if (newElement.textContent !== oldElement.textContent) {
                        driftAnimation(newElement, 'right');
                    }
                }

                // Функция для обновления модели автомобиля
                function updateCarModel() {
                    const carIcon = document.querySelector('.car-icon');
                    if (carIcon) {
                        carIcon.style.setProperty('--car-emoji', `"${getRandomCar()}"`);
                    }
                }

                function createNewCar() {
                    const trackContainer = document.querySelector('.track');
                    const carContainer = document.createElement('div');
                    carContainer.className = 'car-container';
                    
                    const carIcon = document.createElement('div');
                    carIcon.className = 'car-icon';
                    carIcon.style.setProperty('--car-emoji', `"${cars[currentCarIndex]}"`);
                    
                    const driftTrail = document.createElement('div');
                    driftTrail.className = 'drift-trail';
                    
                    carIcon.appendChild(driftTrail);
                    carContainer.appendChild(carIcon);
                    trackContainer.appendChild(carContainer);

                    // Удаляем машину после завершения анимации
                    setTimeout(() => {
                        carContainer.remove();
                    }, 10000);

                    // Обновляем индекс для следующей машины
                    currentCarIndex = (currentCarIndex + 1) % cars.length;
                }

                // Создаем новую машину каждые 10 секунд
                function startCarSpawning() {
                    createNewCar(); // Создаем первую машину сразу
                    setInterval(createNewCar, 10000);
                }

                // Функция для обновления контента
                function refreshStats() {
                    fetch(window.location.href)
                        .then(response => response.text())
                        .then(html => {
                            const parser = new DOMParser();
                            const doc = parser.parseFromString(html, 'text/html');
                            const newContainer = doc.querySelector('.container');
                            const oldContainer = document.querySelector('.container');

                            oldContainer.innerHTML = newContainer.innerHTML;
                            document.title = doc.title;
                            resetTimer();
                        })
                        .catch(error => console.error('Error:', error));
                }

                function resetTimer() {
                    const timerElement = document.getElementById('refresh-timer');
                    let seconds = 30;
                    
                    const countdown = setInterval(() => {
                        seconds--;
                        if (timerElement) {
                            timerElement.textContent = seconds;
                            
                            if (seconds <= 5) {
                                timerElement.classList.add('warning');
                            } else {
                                timerElement.classList.remove('warning');
                            }
                        }
                        if (seconds <= 0) {
                            clearInterval(countdown);
                        }
                    }, 1000);
                }

                // Запускаем автообновление каждые 30 секунд
                setInterval(refreshStats, 30000);

                // Инициализируем таймер и спавн машин при загрузке страницы
                document.addEventListener('DOMContentLoaded', () => {
                    resetTimer();
                    startCarSpawning();

                    // Обработчик для кнопки обновления новостей
                    const newsRefresh = document.querySelector('.news-refresh');
                    if (newsRefresh) {
                        newsRefresh.addEventListener('click', () => {
                            fetch(window.location.href)
                                .then(response => response.text())
                                .then(html => {
                                    const parser = new DOMParser();
                                    const doc = parser.parseFromString(html, 'text/html');
                                    const newNewsContainer = doc.querySelector('.news-container');
                                    const oldNewsContainer = document.querySelector('.news-container');
                                    if (newNewsContainer && oldNewsContainer) {
                                        oldNewsContainer.innerHTML = newNewsContainer.innerHTML;
                                    }
                                })
                                .catch(error => console.error('Error refreshing news:', error));
                        });
                    }
                });
            </script>
<style type="text/css">
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }

body {
	background-color: #000000;
	color: #FFFFFF;
                    font-family: 'Segoe UI', Verdana, Arial, sans-serif;
                    line-height: 1.6;
                    padding: 20px;
                    position: relative;
                    overflow-x: hidden;
                }

                .video-background {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    z-index: -1;
                    object-fit: cover;
                    pointer-events: none;
                    opacity: 0;
                    transition: opacity 1s ease;
                    background-color: #000000;
                    will-change: transform;
                    transform: translateZ(0);
                    backface-visibility: hidden;
                    -webkit-backface-visibility: hidden;
                }

                .video-background.loaded {
                    opacity: 1;
                }

                .video-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(
                        to bottom,
                        rgba(0, 0, 0, 0.7) 0%,
                        rgba(0, 0, 0, 0.3) 50%,
                        rgba(0, 0, 0, 0.7) 100%
                    );
                    z-index: -1;
                    pointer-events: none;
                    mix-blend-mode: multiply;
                }

                .container {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 20px;
                }

                .main-content {
                    grid-column: 1;
                }

                .sidebar {
                    grid-column: 2;
                    position: sticky;
                    top: 20px;
                    height: fit-content;
                }

                .header {
                    background: url("title.png") no-repeat center top;
                    background-size: contain;
                    padding: 120px 0 20px;
                    margin-bottom: 20px;
                    text-align: center;
                    position: relative;
                    animation: titleGlow 2s ease-in-out infinite alternate;
                    transform-style: preserve-3d;
                    perspective: 1000px;
                    will-change: transform, filter;
                }

                @keyframes titleGlow {
                    0% {
                        filter: drop-shadow(0 0 5px rgba(195, 221, 230, 0.3)) 
                                brightness(1) 
                                contrast(1);
                        transform: scale(1) translateZ(0);
                    }
                    50% {
                        filter: drop-shadow(0 0 15px rgba(195, 221, 230, 0.6)) 
                                brightness(1.1) 
                                contrast(1.1);
                        transform: scale(1.02) translateZ(20px);
                    }
                    100% {
                        filter: drop-shadow(0 0 20px rgba(195, 221, 230, 0.8)) 
                                brightness(1.2) 
                                contrast(1.2);
                        transform: scale(1.05) translateZ(30px);
                    }
                }

                .header::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(
                        45deg,
                        transparent 0%,
                        rgba(195, 221, 230, 0.1) 50%,
                        transparent 100%
                    );
                    animation: titleShine 3s linear infinite;
                    mix-blend-mode: overlay;
                    pointer-events: none;
                }

                @keyframes titleShine {
                    0% {
                        transform: translateX(-100%) translateZ(0);
                        opacity: 0;
                    }
                    50% {
                        opacity: 1;
                    }
                    100% {
                        transform: translateX(100%) translateZ(0);
                        opacity: 0;
                    }
                }

                .header::after {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: radial-gradient(
                        circle at center,
                        transparent 0%,
                        rgba(1, 40, 59, 0.2) 50%,
                        transparent 100%
                    );
                    animation: titlePulse 4s ease-in-out infinite;
                    mix-blend-mode: multiply;
                    pointer-events: none;
                }

                @keyframes titlePulse {
                    0% {
                        transform: scale(1) translateZ(0);
                        opacity: 0.5;
                    }
                    50% {
                        transform: scale(1.2) translateZ(0);
                        opacity: 0.8;
                    }
                    100% {
                        transform: scale(1) translateZ(0);
                        opacity: 0.5;
                    }
                }

                .police-tape {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 5px;
                    background: repeating-linear-gradient(
                        45deg,
                        #01283B,
                        #01283B 5px,
                        #C3DDE6 5px,
                        #C3DDE6 10px
                    );
                    background-size: 20px 20px;
                    z-index: 2000;
                    animation: tapeMove 2s linear infinite;
                    box-shadow: 0 2px 10px rgba(1, 40, 59, 0.5);
                }

                .police-tape.bottom {
                    top: auto;
                    bottom: 0;
                }

                @keyframes tapeMove {
                    0% {
                        background-position: 0 0;
                    }
                    100% {
                        background-position: 20px 0;
                    }
                }

                .server-info {
                    background: rgba(1, 40, 59, 0.9);
                    padding: 15px;
                    border-radius: 5px;
                    margin-bottom: 30px;
                    text-align: center;
                    color: #C3DDE6;
                    font-size: 14px;
                    box-shadow: 0 0 15px rgba(1, 40, 59, 0.5);
                }

                .refresh-info {
                    position: fixed;
                    bottom: 20px;
                    left: 50%;
                    transform: translateX(-50%);
                    background: rgba(1, 40, 59, 0.95);
                    padding: 20px;
                    border-radius: 15px;
                    color: #C3DDE6;
                    font-size: 14px;
                    z-index: 1000;
                    transition: all 0.3s ease;
                    box-shadow: 0 0 20px rgba(1, 40, 59, 0.5);
                    min-width: 300px;
                    text-align: center;
                }

                .track-container {
                    position: relative;
                    margin-top: 15px;
                    height: 80px;
                    background: linear-gradient(
                        to bottom,
                        #010c13,
                        #021824 20%,
                        #032030 50%,
                        #021824 80%,
                        #010c13
                    );
                    border-radius: 40px;
                    overflow: hidden;
                    box-shadow: 
                        inset 0 0 30px rgba(1, 40, 59, 0.8),
                        0 0 20px rgba(1, 40, 59, 0.5);
                    transform-style: preserve-3d;
                    perspective: 1000px;
                    will-change: transform;
                    transition: all 0.3s ease;
                }

                .track {
                    position: absolute;
                    top: 50%;
                    left: 0;
                    width: 100%;
                    height: 40px;
                    background: linear-gradient(
                        to bottom,
                        rgba(3, 32, 48, 0.9),
                        rgba(1, 40, 59, 0.5) 50%,
                        rgba(3, 32, 48, 0.9)
                    );
                    transform: translateY(-50%) translateZ(0);
                    will-change: transform;
                    transition: all 0.3s ease;
                }

                .track::before,
                .track::after {
                    content: '';
                    position: absolute;
                    width: 100%;
                    height: 2px;
                    background: linear-gradient(90deg, 
                        transparent 0%,
                        rgba(195, 221, 230, 0.8) 2%,
                        #C3DDE6 50%,
                        rgba(195, 221, 230, 0.8) 98%,
                        transparent 100%
                    );
                    box-shadow: 0 0 10px rgba(195, 221, 230, 0.5);
                    will-change: transform;
                    transition: all 0.3s ease;
                }

                .track::before {
                    top: 0;
                    transform: translateZ(10px);
                }

                .track::after {
                    bottom: 0;
                    transform: translateZ(-10px);
                }

                .track-marks {
                    position: absolute;
                    top: 50%;
                    left: 0;
                    width: 200%;
                    height: 20px;
                    transform: translateY(-50%) translateZ(0);
                    background-image: 
                        repeating-linear-gradient(
                            90deg,
                            transparent,
                            transparent 40px,
                            rgba(195, 221, 230, 0.3) 40px,
                            rgba(195, 221, 230, 0.3) 60px
                        );
                    animation: trackMove 2s linear infinite;
                    will-change: transform;
                    transition: all 0.3s ease;
                }

                .track-overlay {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(
                        90deg,
                        rgba(1, 40, 59, 0.8) 0%,
                        transparent 20%,
                        transparent 80%,
                        rgba(1, 40, 59, 0.8) 100%
                    );
                    pointer-events: none;
                    mix-blend-mode: multiply;
                    transition: all 0.3s ease;
                }

                @keyframes trackMove {
                    0% {
                        transform: translate3d(0, -50%, 0);
                    }
                    100% {
                        transform: translate3d(-50%, -50%, 0);
                    }
                }

                .car-container {
                    position: absolute;
                    top: 50%;
                    left: -30px;
                    transform: translateY(-50%) translateZ(20px);
                    width: 40px;
                    height: 40px;
                    overflow: visible;
                    will-change: transform;
                    transition: all 0.3s ease;
                }

                .car-icon {
                    position: relative;
                    width: 100%;
                    height: 100%;
                    transform-origin: center;
                    animation: carDrive 10s linear;
                    will-change: transform;
                    transition: all 0.3s ease;
                }

                .car-icon::before {
                    content: var(--car-emoji, '🏎️');
                    font-size: 30px;
                    position: absolute;
                    left: 0;
                    top: -15px;
                    filter: drop-shadow(0 0 5px rgba(195, 221, 230, 0.8));
                    transform: scaleX(-1);
                    will-change: transform;
                    transition: all 0.3s ease;
                }

                @keyframes carDrive {
                    0% {
                        transform: translateX(0) rotate(0deg);
                        opacity: 1;
                    }
                    85% {
                        transform: translateX(1100px) rotate(0deg);
                        opacity: 1;
                    }
                    100% {
                        transform: translateX(1200px) rotate(0deg);
                        opacity: 0;
                    }
                }

                .smoke-particles {
                    position: absolute;
                    top: 50%;
                    left: 20px;
                    transform: translateY(-50%) translateZ(0);
                    pointer-events: none;
                    will-change: transform, opacity;
                    transition: all 0.3s ease;
                }

                .checkpoint {
                    position: absolute;
                    top: 0;
                    width: 2px;
                    height: 100%;
                    background: rgba(195, 221, 230, 0.3);
                    transform: translateZ(0);
                    will-change: transform;
                    transition: all 0.3s ease;
                }

                .checkpoint::before {
                    content: '';
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%) translateZ(10px);
                    width: 10px;
                    height: 10px;
                    background: #C3DDE6;
                    border-radius: 50%;
                    box-shadow: 0 0 10px #C3DDE6;
                    will-change: transform;
                    transition: all 0.3s ease;
                }

                .checkpoint-25 { left: 25%; }
                .checkpoint-50 { left: 50%; }
                .checkpoint-75 { left: 75%; }

                @keyframes checkpointPulse {
                    0% {
                        transform: translate(-50%, -50%) scale(1) translateZ(10px);
                        opacity: 1;
                    }
                    50% {
                        transform: translate(-50%, -50%) scale(1.5) translateZ(10px);
                        opacity: 0.5;
                    }
                    100% {
                        transform: translate(-50%, -50%) scale(1) translateZ(10px);
                        opacity: 1;
                    }
                }

                .checkpoint.active::before {
                    animation: checkpointPulse 0.5s ease-in-out;
                }

                .speed-lines {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    pointer-events: none;
                    opacity: 0;
                    will-change: transform, opacity;
                    transition: all 0.3s ease;
                }

                .speed-line {
                    position: absolute;
                    background: linear-gradient(90deg, transparent, rgba(195, 221, 230, 0.3), transparent);
                    height: 1px;
                    width: 100%;
                    transform: translateZ(0);
                    will-change: transform;
                    transition: all 0.3s ease;
                }

                @keyframes speedLines {
                    0% {
                        transform: translateX(100%) translateZ(0);
                        opacity: 0;
                    }
                    50% {
                        opacity: 1;
                    }
                    100% {
                        transform: translateX(-100%) translateZ(0);
                        opacity: 0;
                    }
                }

                .rooms-container {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                    gap: 20px;
                    margin-top: 20px;
                }

                .room-section {
                    background: rgba(1, 40, 59, 0.4);
                    border-radius: 8px;
                    overflow: hidden;
                }

                .room-header {
                    background: #01283B;
                    color: #C3DDE6;
                    padding: 10px;
                    font-weight: bold;
                    text-align: center;
                    font-size: 16px;
                }

                .room-type-header {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    padding: 8px 15px;
                    background: #032030;
                    color: #C3DDE6;
                    font-weight: bold;
                }

                .room-item {
                    padding: 8px 15px;
                    background: #01283B;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }

                .user-item {
                    padding: 6px 15px 6px 30px;
                    background: #021824;
	color: #C3DDE6;
}

                .error {
                    background: #ff000033;
                    color: #ff6666;
                    padding: 15px;
                    border-radius: 5px;
                    text-align: center;
                    margin: 20px auto;
                    max-width: 600px;
                }

                .room-count {
                    background: #032030;
                    padding: 2px 8px;
                    border-radius: 3px;
                    font-size: 0.9em;
                }

                .section-title {
                    font-size: 18px;
                    color: #C3DDE6;
                    margin-bottom: 15px;
                    padding-left: 10px;
                    border-left: 4px solid #01283B;
                }

                @media (max-width: 768px) {
                    .rooms-container {
                        grid-template-columns: 1fr;
                    }
                    
                    .container {
                        padding: 10px;
                    }
                    
                    body {
                        padding: 10px;
                    }

                    .refresh-info {
                        width: 90%;
                        min-width: auto;
                        left: 50%;
                        transform: translateX(-50%);
                        bottom: 10px;
                    }

                    .header {
                        padding: 80px 0 15px;
                        animation: titleGlowMobile 2s ease-in-out infinite alternate;
                    }

                    @keyframes titleGlowMobile {
                        0% {
                            filter: drop-shadow(0 0 3px rgba(195, 221, 230, 0.3)) 
                                    brightness(1) 
                                    contrast(1);
                            transform: scale(1) translateZ(0);
                        }
                        100% {
                            filter: drop-shadow(0 0 10px rgba(195, 221, 230, 0.6)) 
                                    brightness(1.1) 
                                    contrast(1.1);
                            transform: scale(1.03) translateZ(10px);
                        }
                    }
                }

                @keyframes drift-left {
                    0% {
                        opacity: 0.7;
                        transform: translateX(50px) skewX(-10deg);
                    }
                    100% {
                        opacity: 1;
                        transform: translateX(0) skewX(0);
                    }
                }

                @keyframes drift-right {
                    0% {
                        opacity: 0.7;
                        transform: translateX(-50px) skewX(10deg);
                    }
                    100% {
                        opacity: 1;
                        transform: translateX(0) skewX(0);
                    }
                }

                @keyframes drift-bottom {
                    0% {
                        opacity: 0;
                        transform: translateY(-20px) scale(0.95);
                    }
                    100% {
                        opacity: 1;
                        transform: translateY(0) scale(1);
                    }
                }

                .room-section {
                    transition: all 0.3s ease-out;
                    will-change: transform, opacity;
                }

                .room-type-header, .user-item {
                    transition: background-color 0.3s ease;
                }

                .room-type-header:hover {
                    background: #043850;
                }

                .user-item:hover {
                    background: #032840;
                }

                .server-info {
                    animation: drift-bottom 0.5s ease-out;
                }

                .section-title {
                    position: relative;
                    overflow: hidden;
                }

                .section-title::after {
                    content: '';
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    width: 100%;
                    height: 2px;
                    background: linear-gradient(to right, #01283B, transparent);
                    animation: drift-right 1s ease-out infinite;
                }

                /* Добавляем неоновое свечение для комнат */
                .room-section {
                    box-shadow: 0 0 15px rgba(1, 40, 59, 0.3);
                }

                .room-header {
                    position: relative;
                    overflow: hidden;
                }

                .room-header::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: -100%;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(
                        to right,
                        transparent,
                        rgba(195, 221, 230, 0.1),
                        transparent
                    );
                    animation: drift-shine 2s ease-in-out infinite;
                }

                @keyframes drift-shine {
                    0% {
                        left: -100%;
                    }
                    100% {
                        left: 100%;
                    }
                }

                .news-sidebar {
                    position: fixed;
                    right: 20px;
                    top: 30%;
                    transform: translateY(-50%);
                    width: 300px;
                    background: rgba(1, 40, 59, 0.95);
                    border-radius: 15px;
                    padding: 20px;
                    color: #C3DDE6;
                    box-shadow: 0 0 20px rgba(1, 40, 59, 0.5);
                    z-index: 1000;
                    max-height: calc(100vh - 40px);
                    overflow: hidden;
                    margin-bottom: 20px;
                }

                .news-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 15px;
                    padding-bottom: 10px;
                }

                .news-header h2 {
                    margin: 0;
                    font-size: 20px;
                    color: #C3DDE6;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }

                .social-icons {
                    display: flex;
                    gap: 10px;
                }

                .social-icon {
                    width: 24px;
                    height: 24px;
                    background-size: contain;
                    background-repeat: no-repeat;
                    background-position: center;
                    opacity: 0.7;
                    transition: all 0.3s ease;
                }

                .social-icon:hover {
                    opacity: 1;
                    transform: scale(1.1);
                }

                .telegram-icon {
                    background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23C3DDE6"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.2-.08-.06-.19-.04-.27-.02-.12.02-1.98 1.26-5.6 3.7-.53.36-1.01.54-1.44.53-.47-.01-1.37-.26-2.04-.48-.83-.27-1.5-.42-1.44-.88.03-.25.38-.51 1.05-.78 4.12-1.79 6.87-2.97 8.26-3.54 3.93-1.6 4.75-1.88 5.28-1.88.11 0 .36.03.52.18.14.14.18.33.2.52-.01.17-.01.47-.01.47z"/></svg>');
                }

                .instagram-icon {
                    background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23C3DDE6"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>');
                }

                .hot-label {
                    font-size: 14px;
	font-weight: bold;
                    padding: 2px 8px;
                    border-radius: 4px;
                    background: linear-gradient(45deg, #ff0000, #0000ff);
                    color: white;
                    animation: hotGlow 2s ease-in-out infinite alternate;
                }

                @keyframes hotGlow {
                    0% {
                        filter: drop-shadow(0 0 2px #ff0000);
                    }
                    50% {
                        filter: drop-shadow(0 0 5px #0000ff);
                    }
                    100% {
                        filter: drop-shadow(0 0 2px #ff0000);
                    }
                }

                .news-container {
                    display: flex;
                    flex-direction: column;
                    gap: 15px;
                    height: calc(100% - 60px);
                    overflow-y: auto;
                    padding-right: 5px;
                }

                .news-container::-webkit-scrollbar {
                    width: 5px;
                }

                .news-container::-webkit-scrollbar-track {
                    background: rgba(1, 40, 59, 0.3);
                    border-radius: 3px;
                }

                .news-container::-webkit-scrollbar-thumb {
                    background: rgba(195, 221, 230, 0.5);
                    border-radius: 3px;
                }

                .news-container::-webkit-scrollbar-thumb:hover {
                    background: rgba(195, 221, 230, 0.7);
                }

                .news-item {
                    background: rgba(3, 32, 48, 0.5);
                    border-radius: 10px;
                    padding: 15px;
                    transition: all 0.3s ease;
                    opacity: 0;
                    transform: translateY(20px);
                    animation: newsItemAppear 0.5s ease forwards;
                }

                @keyframes newsItemAppear {
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }

                .news-item:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 5px 15px rgba(1, 40, 59, 0.3);
                }

                .error-message {
                    color: #ff6666;
                    text-align: center;
                    padding: 10px;
                    background: rgba(255, 0, 0, 0.1);
                    border-radius: 5px;
                    margin: 10px 0;
                }

                /* Адаптивность для мобильных устройств */
                @media (max-width: 768px) {
                    .news-sidebar {
                        position: static;
                        width: 90%;
                        margin: 20px auto;
                        transform: none;
                        max-height: none;
                    }
                }

                .admin-panel-button {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    z-index: 1000;
                }

                .admin-button {
                    display: inline-block;
                    padding: 8px 16px;
                    background: rgba(3, 32, 48, 0.8);
                    color: #C3DDE6;
                    text-decoration: none;
                    border-radius: 8px;
                    border: 1px solid #043850;
                    transition: all 0.3s ease;
                    font-size: 14px;
                }

                .admin-button:hover {
                    background: rgba(4, 56, 80, 0.8);
                    transform: translateY(-2px);
                    box-shadow: 0 2px 10px rgba(1, 40, 59, 0.5);
                }

                .chat-container {
                    position: fixed;
                    right: 20px;
                    bottom: 100px;
                    width: 300px;
                    background: rgba(1, 40, 59, 0.95);
                    border-radius: 15px;
                    padding: 15px;
                    box-shadow: 0 0 20px rgba(1, 40, 59, 0.5);
                    z-index: 1000;
                    max-height: 400px;
                    display: flex;
                    flex-direction: column;
                    margin-top: 20px;
                }

                .chat-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 10px;
                    padding-bottom: 10px;
                    border-bottom: 1px solid rgba(195, 221, 230, 0.2);
                }

                .chat-header h3 {
                    margin: 0;
                    color: #C3DDE6;
                    font-size: 16px;
                }

                .chat-messages {
                    flex-grow: 1;
                    overflow-y: auto;
                    margin-bottom: 10px;
                    max-height: 300px;
                }

                .chat-message {
                    background: rgba(3, 32, 48, 0.8);
                    padding: 8px 12px;
                    border-radius: 8px;
                    margin-bottom: 8px;
                    color: #C3DDE6;
                }

                .chat-message .username {
                    font-weight: bold;
                    color: #7A9BA8;
                }

                .chat-message .time {
                    font-size: 12px;
                    color: #7A9BA8;
                    margin-left: 5px;
                }

                .chat-input {
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                }

                .chat-input input {
                    background: rgba(3, 32, 48, 0.8);
                    border: 1px solid rgba(195, 221, 230, 0.2);
                    border-radius: 5px;
                    padding: 8px;
                    color: #C3DDE6;
                }

                .chat-input button {
                    background: rgba(3, 32, 48, 0.8);
                    border: 1px solid #043850;
                    border-radius: 5px;
                    padding: 8px 15px;
                    color: #C3DDE6;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }

                .chat-input button:hover {
                    background: rgba(4, 56, 80, 0.8);
                }

                @media (max-width: 768px) {
                    .chat-container {
                        width: 90%;
                        left: 50%;
                        transform: translateX(-50%);
                    }
                }

                .donation-widget {
                    display: none;
                }

                .footer {
                    position: fixed;
                    bottom: 0;
                    left: 0;
                    width: 100%;
                    text-align: center;
                    padding: 10px;
                    background: rgba(1, 40, 59, 0.95);
                    color: #C3DDE6;
                    font-size: 14px;
                    z-index: 1000;
                }

                .footer a {
                    color: #C3DDE6;
                    text-decoration: none;
                }

                .footer a:hover {
                    text-decoration: underline;
                }
            </style>
        </head>
        <body>
            <video class="video-background" autoplay muted loop playsinline preload="metadata" poster="background-poster.jpg">
                <source src="background.mp4" type="video/mp4">
                <source src="background.webm" type="video/webm">
                Your browser does not support the video tag.
            </video>
            <div class="video-overlay"></div>
            <div class="police-tape"></div>
            <div class="admin-panel-button">
                <a href="admin.php" class="admin-button">
                    Admin Panel
                </a>
            </div>
            <div class="container">
                <div class="main-content">
                    <div class="header">
                    </div>
                    <?php if (!$this->error): ?>
                        <div class="server-info">
                            <strong>Server:</strong>
                            <?php echo htmlspecialchars($this->serverData['servername']); ?> 
                            <br>
                            <strong>Version:</strong>
                            <?php echo htmlspecialchars($this->serverData['version']); ?> 
                            (<?php echo htmlspecialchars($this->serverData['platform']); ?>)
                            <br>
                            <strong>Players:</strong>
                            <?php echo $this->serverData['usercount']; ?> 
                            <strong>Rooms:</strong>
                            <?php echo $this->serverData['roomcount']; ?>
                        </div>

                        <div class="section-title">
                            Unranked Rooms
                        </div>
                        <div class="rooms-container">
                            <?php
                            $unrankedTypes = ['E', 'F', 'G', 'H'];
                            foreach ($unrankedTypes as $type) {
                                $this->renderRoomTable($type);
                            }
                            ?>
                        </div>
                    <?php else: ?>
                        <div class="error">
                            <span>Server connection error</span>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="news-sidebar">
                    <div class="news-header">
                        <h2>
                            News
                        </h2>
                        <div class="social-icons">
                            <a href="https://t.me/your_telegram" target="_blank" class="social-icon telegram-icon" title="Telegram"></a>
                            <a href="https://instagram.com/your_instagram" target="_blank" class="social-icon instagram-icon" title="Instagram"></a>
                        </div>
                    </div>
                    <div class="news-container">
                        <?php
                        $newsFile = __DIR__ . '/news.json';
                        if (file_exists($newsFile)) {
                            $news = json_decode(file_get_contents($newsFile), true);
                            if ($news) {
                                foreach ($news as $item) {
                                    ?>
                                    <div class="news-item">
                                        <div class="news-date"><?php echo htmlspecialchars($item['date']); ?></div>
                                        <div class="news-title"><?php echo htmlspecialchars($item['title']); ?></div>
                                        <div class="news-content"><?php echo nl2br(htmlspecialchars($item['content'])); ?></div>
                                    </div>
                                    <?php
                                }
                            }
                        }
                        ?>
                    </div>
                </div>

                <div class="chat-container">
                    <div class="chat-header">
                        <h3>Chat</h3>
                    </div>
                    <div class="chat-messages" id="chatMessages"></div>
                    <div class="chat-input">
                        <input type="text" id="usernameInput" placeholder="Your name..." maxlength="20">
                        <input type="text" id="messageInput" placeholder="Type your message...">
                        <button onclick="sendMessage()">Send</button>
                    </div>
                </div>
            </div>
            <div class="police-tape bottom"></div>
            <div class="footer">
                <p>All rights reserved © 2025 | Developed by <a href="https://github.com/theperce" target="_blank">Perce</a></p>
            </div>

            <div class="donation-widget">
                <div class="donation-header">
                    <h2>Support Us</h2>
                </div>
                <div class="donation-form">
                    <div class="form-group">
                        <label for="username">Your Name:</label>
                        <input type="text" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="amount">Amount:</label>
                        <div class="amount-input">
                            <input type="number" id="amount" name="amount" min="1" step="0.01" required>
                            <select id="currency" name="currency">
                                <option value="USD">USD</option>
                                <option value="EUR">EUR</option>
                                <option value="RUB">RUB</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Payment Method:</label>
                        <div class="payment-methods">
                            <label><input type="radio" name="payment_method" value="paypal" checked> PayPal</label>
                            <label><input type="radio" name="payment_method" value="card"> Credit Card</label>
                            <label><input type="radio" name="payment_method" value="crypto"> Crypto</label>
                        </div>
                    </div>
                    <button type="submit" class="donate-button">Donate Now</button>
                </div>
                <div class="recent-donations">
                    <h3>Recent Donations</h3>
                    <div class="donations-list">
                        <!-- Donations will be loaded here -->
                    </div>
                </div>
            </div>

            <script type="text/javascript">
                document.addEventListener('DOMContentLoaded', function() {
                    // Initialize page
                    loadMessages();
                });

                function loadMessages() {
                    fetch('chat.php?action=get')
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Network response was not ok');
                            }
                            return response.json();
                        })
                        .then(messages => {
                            const chatMessages = document.getElementById('chatMessages');
                            if (chatMessages) {
                                chatMessages.innerHTML = '';
                                messages.forEach(message => {
                                    addMessageToChat(message);
                                });
                            }
                        })
                        .catch(error => {
                            console.error('Error loading messages:', error);
                            const chatMessages = document.getElementById('chatMessages');
                            if (chatMessages) {
                                chatMessages.innerHTML = '<div class="error-message">Error loading messages. Please try again later.</div>';
                            }
                        });
                }

                function sendMessage() {
                    const usernameInput = document.getElementById('usernameInput');
                    const messageInput = document.getElementById('messageInput');
                    
                    if (!usernameInput || !messageInput) {
                        console.error('Chat input elements not found');
                        return;
                    }

                    const username = usernameInput.value.trim();
                    const message = messageInput.value.trim();
                    
                    if (!message || !username) {
                        alert('Please enter both username and message');
                        return;
                    }

                    if (message.length > 500) {
                        alert('Message is too long. Maximum 500 characters allowed.');
                        return;
                    }
                    
                    fetch('chat.php?action=send', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'username=' + encodeURIComponent(username) + '&message=' + encodeURIComponent(message)
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success) {
                            messageInput.value = '';
                            loadMessages();
                        } else {
                            throw new Error(data.error || 'Failed to send message');
                        }
                    })
                    .catch(error => {
                        console.error('Error sending message:', error);
                        alert('Failed to send message. Please try again later.');
                    });
                }

                function addMessageToChat(message) {
                    const chatMessages = document.getElementById('chatMessages');
                    if (!chatMessages) return;

                    const messageElement = document.createElement('div');
                    messageElement.className = 'chat-message';
                    
                    // Экранирование HTML для безопасности
                    const safeUsername = message.username.replace(/[&<>"']/g, function(m) {
                        return {
                            '&': '&amp;',
                            '<': '&lt;',
                            '>': '&gt;',
                            '"': '&quot;',
                            "'": '&#39;'
                        }[m];
                    });
                    
                    const safeMessage = message.text.replace(/[&<>"']/g, function(m) {
                        return {
                            '&': '&amp;',
                            '<': '&lt;',
                            '>': '&gt;',
                            '"': '&quot;',
                            "'": '&#39;'
                        }[m];
                    });

                    messageElement.innerHTML = `
                        <span class="username">${safeUsername}</span>
                        <span class="time">${message.time}</span>
                        <div class="message-text">${safeMessage}</div>
                    `;
                    chatMessages.appendChild(messageElement);
                    chatMessages.scrollTop = chatMessages.scrollHeight;
                }

                function clearChat() {
                    const chatMessages = document.getElementById('chatMessages');
                    if (chatMessages) {
                        chatMessages.innerHTML = '';
                        // Отправляем запрос на сервер для очистки сообщений
                        fetch('chat.php?action=clear', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                            }
                        })
                        .catch(error => console.error('Error clearing chat:', error));
                    }
                }

                // Auto-refresh messages every 5 seconds
                let messageRefreshInterval = setInterval(loadMessages, 5000);
                // Auto-clear chat every 5 minutes
                let chatClearInterval = setInterval(clearChat, 300000);

                // Очистка интервалов при размонтировании компонента
                window.addEventListener('beforeunload', function() {
                    clearInterval(messageRefreshInterval);
                    clearInterval(chatClearInterval);
                });

                // Donation system
                function loadDonationSettings() {
                    fetch('donate.php?action=get_settings')
                        .then(response => response.json())
                        .then(settings => {
                            const form = document.querySelector('.donation-form');
                            form.querySelector('#amount').min = settings.min_amount;
                            form.querySelector('#amount').max = settings.max_amount;
                            form.querySelector('#currency').value = settings.currency;
                            
                            // Update payment methods
                            const paymentMethods = form.querySelectorAll('input[name="payment_method"]');
                            paymentMethods.forEach(input => {
                                input.disabled = !settings.payment_methods.includes(input.value);
                            });
                        })
                        .catch(error => console.error('Error loading donation settings:', error));
                }

                function loadRecentDonations() {
                    fetch('donate.php?action=get_recent')
                        .then(response => response.json())
                        .then(donations => {
                            const list = document.querySelector('.donations-list');
                            list.innerHTML = '';
                            
                            donations.forEach(donation => {
                                const div = document.createElement('div');
                                div.className = 'donation-item';
                                div.innerHTML = `
                                    <span class="username">${donation.username}</span>
                                    <span class="amount">${donation.amount} ${donation.currency}</span>
                                    <span class="date">${new Date(donation.created_at).toLocaleString()}</span>
                                `;
                                list.appendChild(div);
                            });
                        })
                        .catch(error => console.error('Error loading donations:', error));
                }

                // Handle donation form submission
                document.querySelector('.donation-form').addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const formData = {
                        username: this.querySelector('#username').value,
                        amount: parseFloat(this.querySelector('#amount').value),
                        currency: this.querySelector('#currency').value,
                        payment_method: this.querySelector('input[name="payment_method"]:checked').value
                    };
                    
                    fetch('donate.php?action=create', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(formData)
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('Thank you for your donation!');
                            loadRecentDonations();
                        }
                    })
                    .catch(error => console.error('Error processing donation:', error));
                });

                // Initialize donation system
                document.addEventListener('DOMContentLoaded', function() {
                    loadDonationSettings();
                    loadRecentDonations();
                    setInterval(loadRecentDonations, 30000); // Refresh every 30 seconds
                });
            </script>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const video = document.querySelector('.video-background');
                    if (!video) return;

                    // Оптимизация загрузки видео
                    video.addEventListener('loadeddata', function() {
                        video.classList.add('loaded');
                    });

                    // Обработка ошибок загрузки
                    video.addEventListener('error', function(e) {
                        console.error('Error loading video:', e);
                        video.style.display = 'none';
                        document.body.style.background = 'linear-gradient(to bottom, #000000 0%, #01283B 50%, #000000 100%)';
                    });

                    // Проверка готовности видео
                    if (video.readyState >= 2) {
                        video.classList.add('loaded');
                    }

                    // Оптимизация производительности
                    video.addEventListener('canplay', function() {
                        const playPromise = video.play();
                        if (playPromise !== undefined) {
                            playPromise.catch(function(error) {
                                console.error('Error playing video:', error);
                                video.style.display = 'none';
                                document.body.style.background = 'linear-gradient(to bottom, #000000 0%, #01283B 50%, #000000 100%)';
                            });
                        }
                    });

                    // Обработка изменения размера окна
                    let resizeTimeout;
                    window.addEventListener('resize', function() {
                        clearTimeout(resizeTimeout);
                        resizeTimeout = setTimeout(function() {
                            if (window.innerWidth <= 768) {
                                video.style.display = 'none';
                                document.body.style.background = 'linear-gradient(to bottom, #000000 0%, #01283B 50%, #000000 100%)';
                            } else {
                                video.style.display = 'block';
                                document.body.style.background = 'none';
                            }
                        }, 250);
                    });

                    // Проверка поддержки видео
                    if (!video.canPlayType('video/mp4') && !video.canPlayType('video/webm')) {
                        video.style.display = 'none';
                        document.body.style.background = 'linear-gradient(to bottom, #000000 0%, #01283B 50%, #000000 100%)';
                    }
                });
            </script>
            <script>
                // Language switching functionality
                function switchLanguage(lang) {
                    // Сохраняем выбранный язык
                    localStorage.setItem('selectedLanguage', lang);
                    
                    // Обновляем активную кнопку
                    document.querySelectorAll('.language-button').forEach(button => {
                        button.classList.remove('active');
                        if (button.getAttribute('data-lang') === lang) {
                            button.classList.add('active');
                        }
                    });

                    // Показываем элементы с выбранным языком
                    document.querySelectorAll('[data-lang]').forEach(element => {
                        if (element.getAttribute('data-lang') === lang) {
                            element.style.display = 'inline';
                        } else {
                            element.style.display = 'none';
                        }
                    });

                    // Обновляем заголовок страницы
                    document.title = lang === 'ru' ? 'Статистика сервера' : 'Server Statistics';
                }

                // Инициализация языка при загрузке страницы
                document.addEventListener('DOMContentLoaded', function() {
                    const savedLanguage = localStorage.getItem('selectedLanguage') || 'ru';
                    switchLanguage(savedLanguage);

                    // Добавляем обработчики для кнопок переключения языка
                    document.querySelectorAll('.language-button').forEach(button => {
                        button.addEventListener('click', function() {
                            const lang = this.getAttribute('data-lang');
                            switchLanguage(lang);
                        });
                    });
                });
            </script>
        </body>
        </html>
        <?php
    }

    private function renderRoomTable(string $roomType): void {
        $rooms = array_filter($this->rooms, function(Room $room) use ($roomType): bool {
            return $room->getType() === $roomType;
        });

        if (empty($rooms)) {
            return;
        }
        ?>
        <div class="room-section">
            <div class="room-header">
                <?php echo $GLOBALS['ROOM_TYPES'][$roomType]; ?>
            </div>
            <?php
            foreach ($rooms as $room) {
                ?>
                <div class="room">
                    <div class="room-name">
                        <?php echo htmlspecialchars($room->getName()); ?>
                    </div>
                    <div class="room-info">
                        <span class="room-players">
                            <?php echo $room->getUserCount(); ?> players
                        </span>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
        <?php
    }
}

$stats = new ServerStats();
$stats->connect();
$stats->render();
?>

