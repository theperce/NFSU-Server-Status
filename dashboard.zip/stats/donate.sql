CREATE TABLE IF NOT EXISTS `donations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) NOT NULL DEFAULT 'USD',
  `status` enum('pending','completed','failed') NOT NULL DEFAULT 'pending',
  `payment_method` varchar(50) NOT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `donation_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `min_amount` decimal(10,2) NOT NULL DEFAULT '1.00',
  `max_amount` decimal(10,2) NOT NULL DEFAULT '1000.00',
  `currency` varchar(3) NOT NULL DEFAULT 'USD',
  `payment_methods` text NOT NULL,
  `thank_you_message` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `donation_settings` (`min_amount`, `max_amount`, `currency`, `payment_methods`, `thank_you_message`, `is_active`) VALUES
(1.00, 1000.00, 'USD', '["paypal","card","crypto"]', 'Thank you for your donation!', 1); 