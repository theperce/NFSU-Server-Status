<?php
header('Content-Type: application/json');

$chatFile = __DIR__ . '/chat.json';
$maxMessages = 100;

// Initialize chat file if it doesn't exist
if (!file_exists($chatFile)) {
    file_put_contents($chatFile, json_encode([]));
}

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'get':
        $messages = json_decode(file_get_contents($chatFile), true);
        echo json_encode($messages);
        break;

    case 'send':
        $message = $_POST['message'] ?? '';
        $username = $_POST['username'] ?? '';
        
        if (!empty($message) && !empty($username)) {
            $messages = json_decode(file_get_contents($chatFile), true);
            
            // Add new message
            $messages[] = [
                'username' => htmlspecialchars($username),
                'text' => htmlspecialchars($message),
                'time' => date('H:i:s')
            ];
            
            // Keep only last $maxMessages messages
            if (count($messages) > $maxMessages) {
                $messages = array_slice($messages, -$maxMessages);
            }
            
            file_put_contents($chatFile, json_encode($messages));
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Empty message or username']);
        }
        break;

    default:
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
        break;
} 