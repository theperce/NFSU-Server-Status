<?php
session_start();

// Конфигурация
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'admin');
define('NEWS_FILE', __DIR__ . '/news.json');

// Функция для безопасного сохранения файла
function safe_file_put_contents($file, $data) {
    $tempFile = $file . '.tmp';
    if (file_put_contents($tempFile, $data) === false) {
        return false;
    }
    return rename($tempFile, $file);
}

// Функция для загрузки новостей
function loadNews() {
    if (!file_exists(NEWS_FILE)) {
        return [];
    }
    $news = json_decode(file_get_contents(NEWS_FILE), true);
    return $news ?: [];
}

// Функция для сохранения новостей
function saveNews($news) {
    return safe_file_put_contents(NEWS_FILE, json_encode($news, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

// Обработка входа
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'login') {
        if ($_POST['username'] === ADMIN_USERNAME && $_POST['password'] === ADMIN_PASSWORD) {
            $_SESSION['admin'] = true;
            header('Location: admin.php');
            exit;
        } else {
            $error = 'Неверные учетные данные';
        }
    } elseif ($_POST['action'] === 'logout') {
        session_destroy();
        header('Location: admin.php');
        exit;
    } elseif ($_POST['action'] === 'add_news') {
        if (isset($_SESSION['admin'])) {
            $news = loadNews();
            $news[] = [
                'date' => date('Y-m-d'),
                'title' => $_POST['title'],
                'content' => $_POST['content']
            ];
            saveNews($news);
            header('Location: admin.php');
            exit;
        }
    } elseif ($_POST['action'] === 'delete_news') {
        if (isset($_SESSION['admin'])) {
            $news = loadNews();
            $index = $_POST['index'];
            if (isset($news[$index])) {
                array_splice($news, $index, 1);
                saveNews($news);
            }
            header('Location: admin.php');
            exit;
        }
    }
}

// Загрузка новостей
$news = loadNews();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ-панель</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #012837;
            color: #C3DDE6;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background: rgba(1, 40, 59, 0.95);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(1, 40, 59, 0.5);
        }

        h1 {
            text-align: center;
            color: #C3DDE6;
            margin-bottom: 30px;
        }

        .login-form {
            max-width: 300px;
            margin: 0 auto;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"],
        textarea {
            width: 100%;
            padding: 8px;
            background: rgba(3, 32, 48, 0.5);
            border: 1px solid #032030;
            border-radius: 8px;
            color: #C3DDE6;
        }

        button {
            background: #032030;
            border: 1px solid #043850;
            border-radius: 8px;
            padding: 8px 15px;
            color: #C3DDE6;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        button:hover {
            background: #043850;
        }

        .error {
            color: #ff4444;
            text-align: center;
            margin-bottom: 15px;
        }
        
        .news-list {
            margin-top: 30px;
        }

        .news-item {
            background: rgba(3, 32, 48, 0.5);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            border: 1px solid #032030;
        }

        .news-item h3 {
            margin-top: 0;
            color: #C3DDE6;
        }
        
        .news-item .date {
            color: #7A9BA8;
            font-size: 12px;
        }

        .news-item .content {
            margin-top: 10px;
        }

        .add-news-form {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #032030;
        }

        .logout-btn {
            position: absolute;
            top: 20px;
            right: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (!isset($_SESSION['admin'])): ?>
            <h1>Вход в админ-панель</h1>
            <?php if (isset($error)): ?>
                <div class="error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            <form class="login-form" method="POST">
                <input type="hidden" name="action" value="login">
                <div class="form-group">
                    <label for="username">Логин:</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Пароль:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit">Войти</button>
            </form>
        <?php else: ?>
            <form method="POST" class="logout-btn">
                <input type="hidden" name="action" value="logout">
                <button type="submit">Выйти</button>
            </form>
            
            <h1>Управление новостями</h1>
            
            <div class="add-news-form">
                <h2>Добавить новость</h2>
                <form method="POST">
                    <input type="hidden" name="action" value="add_news">
                    <div class="form-group">
                        <label for="title">Заголовок:</label>
                        <input type="text" id="title" name="title" required>
                    </div>
                    <div class="form-group">
                        <label for="content">Содержание:</label>
                        <textarea id="content" name="content" rows="4" required></textarea>
                    </div>
                    <button type="submit">Добавить новость</button>
                </form>
            </div>

            <div class="news-list">
                <h2>Список новостей</h2>
                <?php foreach ($news as $index => $item): ?>
                    <div class="news-item">
                        <h3><?php echo htmlspecialchars($item['title']); ?></h3>
                        <div class="date"><?php echo htmlspecialchars($item['date']); ?></div>
                        <div class="content"><?php echo nl2br(htmlspecialchars($item['content'])); ?></div>
                        <form method="POST" style="margin-top: 10px;">
                            <input type="hidden" name="action" value="delete_news">
                            <input type="hidden" name="index" value="<?php echo $index; ?>">
                            <button type="submit">Удалить</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html> 